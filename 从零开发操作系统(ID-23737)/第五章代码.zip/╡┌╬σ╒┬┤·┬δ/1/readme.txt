dd if=pm.bin of=e:\d123.vhd bs=512 count=100 seek=20
dd if=kernel.bin of=e:\d123.vhd bs=512 count=100 seek=9
9和20不能错